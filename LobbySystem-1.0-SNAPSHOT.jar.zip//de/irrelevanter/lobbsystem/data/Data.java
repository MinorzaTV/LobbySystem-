package de.irrelevanter.lobbsystem.data;

import java.io.File;
import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;

public class Data {
   public static String Prefix = "§8[§cLobby§8] ";
   public static String NoPerm;
   public static File file;
   public static YamlConfiguration cfg;
   public static Location spawn;
   public static Location spawn1;
   public static Location spawn2;
   public static Location spawn3;
   public static Location spawn4;
   public static Location spawn5;
   public static Location spawn6;

   static {
      NoPerm = Prefix + "§cDu hast keine Rechte um dies zu tun!";
      file = new File("plugins//LobbySystem//spawns.yml");
      cfg = YamlConfiguration.loadConfiguration(file);
   }
}
