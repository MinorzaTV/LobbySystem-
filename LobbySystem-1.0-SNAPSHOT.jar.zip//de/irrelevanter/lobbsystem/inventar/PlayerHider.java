package de.irrelevanter.lobbsystem.inventar;

import de.irrelevanter.lobbsystem.data.Data;
import java.util.ArrayList;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PlayerHider implements Listener {
   static ArrayList<Player> hidden = new ArrayList();

   @EventHandler
   public void onInteract(PlayerInteractEvent e) {
      Player p = e.getPlayer();

      try {
         if (e.getItem().getType() == Material.BLAZE_ROD) {
            p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0F, 1.0F);
            Inventory inv = Bukkit.createInventory((InventoryHolder)null, InventoryType.HOPPER, "§eSpieler Verstecken");
            ItemStack i = new ItemStack(Material.INK_SACK, 1, (short)10);
            ItemMeta im = i.getItemMeta();
            im.setDisplayName("§aSpieler anzeigen");
            i.setItemMeta(im);
            ItemStack a = new ItemStack(Material.INK_SACK, 1, (short)1);
            ItemMeta am = a.getItemMeta();
            am.setDisplayName("§cSpieler verstecken");
            a.setItemMeta(am);
            inv.setItem(1, i);
            inv.setItem(3, a);
            p.openInventory(inv);
         }
      } catch (Exception var8) {
      }

   }

   @EventHandler
   public void onClic(InventoryClickEvent e) {
      Player p = (Player)e.getWhoClicked();
      if (e.getInventory().getName().equalsIgnoreCase("§eSpieler Verstecken")) {
         e.setCancelled(true);
         Location loc;
         Location ent;
         Iterator var5;
         Player all;
         if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aSpieler anzeigen")) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 5, 999999));
            loc = p.getLocation();
            ent = p.getLocation();
            ent.setX(loc.getX() + 2.0D);
            ent.setX(loc.getZ() + 2.0D);
            loc.setY(loc.getY() + 2.0D);
            p.playEffect(ent, Effect.LAVA_POP, 11);
            p.teleport(loc);
            var5 = Bukkit.getOnlinePlayers().iterator();

            while(var5.hasNext()) {
               all = (Player)var5.next();
               p.showPlayer(all);
               hidden.remove(p);
            }

            p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 1.0F, 1.0F);
            p.sendMessage(Data.Prefix + "§7Alle Spieler sind nun für dich §asichtbar§7!");
            p.closeInventory();
            return;
         }

         if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cSpieler verstecken")) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 5, 999999));
            loc = p.getLocation();
            ent = p.getLocation();
            ent.setX(loc.getX() + 2.0D);
            ent.setX(loc.getZ() + 2.0D);
            loc.setY(loc.getY() + 2.0D);
            p.playEffect(ent, Effect.LAVA_POP, 11);
            p.teleport(loc);
            var5 = Bukkit.getOnlinePlayers().iterator();

            while(var5.hasNext()) {
               all = (Player)var5.next();
               hidden.add(p);
               p.hidePlayer(all);
            }

            p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 1.0F, 1.0F);
            p.sendMessage(Data.Prefix + "§7Alle Spieler sind nun für dich §cunsichtbar§7!");
            p.closeInventory();
         }
      }

   }

   @EventHandler
   public void onJoin(PlayerJoinEvent e) {
      Player p = e.getPlayer();
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player all = (Player)var3.next();
         if (hidden.contains(all)) {
            all.hidePlayer(p);
         }
      }

   }
}
