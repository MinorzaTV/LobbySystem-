package de.irrelevanter.lobbsystem.main;

import de.irrelevanter.lobbsystem.commands.SetSpawn;
import de.irrelevanter.lobbsystem.data.Data;
import de.irrelevanter.lobbsystem.inventar.Compass;
import de.irrelevanter.lobbsystem.inventar.LobbySwitcher;
import de.irrelevanter.lobbsystem.inventar.PlayerHider;
import de.irrelevanter.lobbsystem.listener.LobbyProtection;
import de.irrelevanter.lobbsystem.listener.MainListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
   static int i;
   public static ItemStack OnlineLobby;
   public static ItemStack OfflineLobby;

   public void onEnable() {
      i = 0;
      Bukkit.getConsoleSender().sendMessage("§6LobbySystem wird aktiviert...");
      Bukkit.getPluginManager().registerEvents(new Compass(this), this);
      Bukkit.getPluginManager().registerEvents(new PlayerHider(), this);
      Bukkit.getPluginManager().registerEvents(new LobbyProtection(), this);
      Bukkit.getPluginManager().registerEvents(new LobbySwitcher(this), this);
      Bukkit.getPluginManager().registerEvents(new MainListener(), this);
      Bukkit.getPluginManager().registerEvents(new SetSpawn(), this);
      this.updateLobbys();
      this.load1();
      this.load2();
      this.load3();
      this.load4();
      this.load5();
      this.load6();
      this.loadLocations();
   }

   public void onDisable() {
      Bukkit.getConsoleSender().sendMessage("§6LobbySystem wird deaktiviert...");
   }

   public void loadLocations() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("Spawn.WeltName");
      double x = cfg.getDouble("Spawn.X");
      double y = cfg.getDouble("Spawn.Y");
      double z = cfg.getDouble("Spawn.Z");
      double yaw = cfg.getDouble("Spawn.Yaw");
      double pitch = cfg.getDouble("Spawn.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn = loc;
   }

   public void load1() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("1.WeltName");
      double x = cfg.getDouble("1.X");
      double y = cfg.getDouble("1.Y");
      double z = cfg.getDouble("1.Z");
      double yaw = cfg.getDouble("1.Yaw");
      double pitch = cfg.getDouble("1.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn1 = loc;
   }

   public void load2() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("2.WeltName");
      double x = cfg.getDouble("2.X");
      double y = cfg.getDouble("2.Y");
      double z = cfg.getDouble("2.Z");
      double yaw = cfg.getDouble("2.Yaw");
      double pitch = cfg.getDouble("2.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn2 = loc;
   }

   public void load3() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("3.WeltName");
      double x = cfg.getDouble("3.X");
      double y = cfg.getDouble("3.Y");
      double z = cfg.getDouble("3.Z");
      double yaw = cfg.getDouble("3.Yaw");
      double pitch = cfg.getDouble("3.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn3 = loc;
   }

   public void load4() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("4.WeltName");
      double x = cfg.getDouble("4.X");
      double y = cfg.getDouble("4.Y");
      double z = cfg.getDouble("4.Z");
      double yaw = cfg.getDouble("4.Yaw");
      double pitch = cfg.getDouble("4.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn4 = loc;
   }

   public void load5() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("5.WeltName");
      double x = cfg.getDouble("5.X");
      double y = cfg.getDouble("5.Y");
      double z = cfg.getDouble("5.Z");
      double yaw = cfg.getDouble("5.Yaw");
      double pitch = cfg.getDouble("5.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn5 = loc;
   }

   public void load6() {
      File file = new File("plugins//LobbySystem//spawns.yml");
      YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
      String w = cfg.getString("6.WeltName");
      double x = cfg.getDouble("6.X");
      double y = cfg.getDouble("6.Y");
      double z = cfg.getDouble("6.Z");
      double yaw = cfg.getDouble("6.Yaw");
      double pitch = cfg.getDouble("6.Pitch");
      Location loc = new Location(Bukkit.getWorld(w), x, y, z);
      loc.setYaw((float)yaw);
      loc.setPitch((float)pitch);
      Data.spawn6 = loc;
   }

   public void updateLobbys() {
      Bukkit.getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
         public void run() {
            ItemStack online;
            ItemMeta om;
            ArrayList list;
            ItemStack offline;
            ItemMeta ofm;
            ArrayList list1;
            if (Main.i == 0) {
               online = new ItemStack(Material.STAINED_CLAY, Bukkit.getOnlinePlayers().size(), (short)5);
               om = online.getItemMeta();
               om.setDisplayName("§aLobby-01§8 » §2Online");
               list = new ArrayList();
               list.add("§7§m------------------------");
               list.add("§6Online§8 » §3" + Bukkit.getOnlinePlayers().size());
               list.add("§6Status §8» §2Online");
               list.add("§6Aktualisieren:");
               list.add("§7§m------------------------");
               om.setLore(list);
               online.setItemMeta(om);
               offline = new ItemStack(Material.STAINED_CLAY, 0, (short)14);
               ofm = offline.getItemMeta();
               ofm.setDisplayName("§aLobby §8» §cWird bei Bedarf gestartet");
               list1 = new ArrayList();
               list1.add("§7§m------------------------");
               list1.add("§6Online§8 » §30");
               list1.add("§6Status §8» §cOffline");
               list1.add("§6Aktualisieren:");
               list1.add("§7§m------------------------");
               ofm.setLore(list1);
               offline.setItemMeta(ofm);
               Main.OfflineLobby = offline;
               Main.OnlineLobby = online;
            }

            ++Main.i;
            Iterator var7 = Bukkit.getOnlinePlayers().iterator();

            while(var7.hasNext()) {
               Player all = (Player)var7.next();
               if (LobbySwitcher.into.contains(all)) {
                  Inventory inv = Bukkit.createInventory((InventoryHolder)null, 9, "§6Lobby Switcher");
                  inv.setItem(0, Main.OnlineLobby);
                  inv.setItem(1, Main.OfflineLobby);
                  inv.setItem(2, Main.OfflineLobby);
                  inv.setItem(3, Main.OfflineLobby);
                  inv.setItem(4, Main.OfflineLobby);
                  inv.setItem(5, Main.OfflineLobby);
                  inv.setItem(6, Main.OfflineLobby);
                  inv.setItem(7, Main.OfflineLobby);
                  inv.setItem(8, Main.OfflineLobby);
                  LobbySwitcher.into.remove(all);
                  all.openInventory(inv);
                  LobbySwitcher.into.add(all);
               }
            }

            if (Main.i == 1) {
               online = new ItemStack(Material.STAINED_CLAY, Bukkit.getOnlinePlayers().size(), (short)5);
               om = online.getItemMeta();
               om.setDisplayName("§aLobby-01§8 » §2Online");
               list = new ArrayList();
               list.add("§7§m------------------------");
               list.add("§6Online§8 » §3" + Bukkit.getOnlinePlayers().size());
               list.add("§6Status §8» §2Online");
               list.add("§6Aktualisieren: §a•");
               list.add("§7§m------------------------");
               om.setLore(list);
               online.setItemMeta(om);
               offline = new ItemStack(Material.STAINED_CLAY, 0, (short)14);
               ofm = offline.getItemMeta();
               ofm.setDisplayName("§aLobby §8» §cWird bei Bedarf gestartet");
               list1 = new ArrayList();
               list1.add("§7§m------------------------");
               list1.add("§6Online§8 » §30");
               list1.add("§6Status §8» §cOffline");
               list1.add("§6Aktualisieren: §a•");
               list1.add("§7§m------------------------");
               ofm.setLore(list1);
               offline.setItemMeta(ofm);
               Main.OfflineLobby = offline;
               Main.OnlineLobby = online;
            }

            if (Main.i == 2) {
               online = new ItemStack(Material.STAINED_CLAY, Bukkit.getOnlinePlayers().size(), (short)5);
               om = online.getItemMeta();
               om.setDisplayName("§aLobby-01§8 » §2Online");
               list = new ArrayList();
               list.add("§7§m------------------------");
               list.add("§6Online§8 » §3" + Bukkit.getOnlinePlayers().size());
               list.add("§6Status §8» §2Online");
               list.add("§6Aktualisieren: §a• §e•");
               list.add("§7§m------------------------");
               om.setLore(list);
               online.setItemMeta(om);
               offline = new ItemStack(Material.STAINED_CLAY, 0, (short)14);
               ofm = offline.getItemMeta();
               ofm.setDisplayName("§aLobby §8» §cWird bei Bedarf gestartet");
               list1 = new ArrayList();
               list1.add("§7§m------------------------");
               list1.add("§6Online§8 » §30");
               list1.add("§6Status §8» §cOffline");
               list1.add("§6Aktualisieren: §a• §e•");
               list1.add("§7§m------------------------");
               ofm.setLore(list1);
               offline.setItemMeta(ofm);
               Main.OfflineLobby = offline;
               Main.OnlineLobby = online;
            }

            if (Main.i == 3) {
               online = new ItemStack(Material.STAINED_CLAY, Bukkit.getOnlinePlayers().size(), (short)5);
               om = online.getItemMeta();
               om.setDisplayName("§aLobby-01§8 » §2Online");
               list = new ArrayList();
               list.add("§7§m------------------------");
               list.add("§6Online§8 » §3" + Bukkit.getOnlinePlayers().size());
               list.add("§6Status §8» §2Online");
               list.add("§6Aktualisieren: §a• §e• §c•");
               list.add("§7§m------------------------");
               om.setLore(list);
               online.setItemMeta(om);
               offline = new ItemStack(Material.STAINED_CLAY, 0, (short)14);
               ofm = offline.getItemMeta();
               ofm.setDisplayName("§aLobby §8» §cWird bei Bedarf gestartet");
               list1 = new ArrayList();
               list1.add("§7§m------------------------");
               list1.add("§6Online§8 » §30");
               list1.add("§6Status §8» §cOffline");
               list1.add("§6Aktualisieren: §a• §e• §c•");
               list1.add("§7§m------------------------");
               ofm.setLore(list1);
               offline.setItemMeta(ofm);
               Main.OfflineLobby = offline;
               Main.OnlineLobby = online;
            }

            if (Main.i == 4) {
               Main.i = 0;
            }

         }
      }, 20L, 10L);
   }
}
