package de.irrelevanter.lobbsystem.listener;

import de.irrelevanter.lobbsystem.data.Data;
import de.irrelevanter.lobbsystem.methods.Methods;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {
   public void onJoin(PlayerJoinEvent e) {
      Player p = e.getPlayer();
      e.setJoinMessage((String)null);
      Methods.setLobbyItems(p);
      p.setHealth(6.0D);
      p.setFoodLevel(6);
      p.teleport(Data.spawn);
   }
}
